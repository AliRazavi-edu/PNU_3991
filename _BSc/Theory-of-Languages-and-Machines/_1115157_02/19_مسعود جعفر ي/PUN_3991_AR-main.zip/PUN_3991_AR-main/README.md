> ارزیابی ها


##  بخش عمومی
- - [ارزیابی رزومه و انگیزه نامه](XX_CV_CheckList_AR_3991.pdf)
- - [خلاصه ارزیابی بخش عمومی](XX_GeneralSection_CheckList_AR_3991.pdf)




- [خلاصه ارزیابی درس نظریه زبان و ماشین](https://github.com/mir-mohammad/PNU_3991_AR/blob/main/Theory-of-Languages-and-Machines/XX_Theory-of-Languages-and-Machines_CheckList_AR_3991.pdf)







# PUN_3991_AR

### مسعود جعفری

---
- [حساب گیت هاب](https://github.com/masoudjfr)
- [آدرس رزومه](https://masoudjfr.github.io/Resume/)
- [SOP](https://masoudjfr.github.io/SOP/)


-------------------
## Winter Semester Courses 1399/2020

## دروس کارشناسی

[1115157_01 & 02 نظريه زبانهاوماشين ها 3](https://github.com/AliRazavi-edu/PNU_3991/tree/master/_BSc/Theory-of-Languages-and-Machines)
-----------------
## روز و ساعت ارائه دروس

<table style="width:100%">
  <tr>
    <th >16-18</th>
    <th >14-16</th>
    <th >12-14</th>
    <th>10-12</th>
    <th>8-10</th>
    <th>روز</th>
   </tr>
  <tr>
    <th ></th>
    <th ><a  href="https://github.com/AliRazavi-edu/PNU_3991/tree/master/_BSc/Theory-of-Languages-and-Machines">نظريه زبانهاوماشين ها 02-1115157</a></th>
    <th ><a href="https://github.com/AliRazavi-edu/PNU_3991/tree/master/_BSc/Theory-of-Languages-and-Machines" >نظريه زبانهاوماشين ها 01-1115157</a></th>
    <th></th>
    <th></th>
    <th>شنبه</th>
  </tr>
   <tr>
    <th ></th>
    <th ></th>
    <th></th>
    <th></th>
    <th ></th>
    <th>یک شنبه</th>
  </tr>
   <tr>
     <th ><a </a> </th>
     <th ><a </a></th>
     <th><a </a></th>
     <th><a </a></th>
    <th ></th>   
    <th>دوشنبه</th>
  </tr>
   <tr>
    <th ></th>
    <th ></th>
    <th></th>
    <th></th>
    <th ></th>
    <th>سه شنبه</th>
  </tr>
   <tr>
    <th ></th>
    <th ></th>
    <th></th>
    <th></th>
     <th ><a </a></th>
    <th>چهارشنبه</th>
  </tr>
   <tr>
    <th ></th>
     <th ><a  </a></th>
     <th ><a </a></th>
     <th><a  </a></th>
    <th><a </a></th>
    <th>پنج شنبه</th>
  </tr>
</table>
