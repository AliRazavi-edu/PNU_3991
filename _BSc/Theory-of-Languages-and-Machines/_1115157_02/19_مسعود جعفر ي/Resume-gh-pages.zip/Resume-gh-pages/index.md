   درباره من :
   
اینجانب مسعود جعفری هستم
اینجانب در حال تحصیل در دانشگاه پیام نور مرکز تهران شمال و مشغول به کار در شرکت مهندسی شبکه گستران آریا سامانه در حوزه پشتیبانی هستم

   شماره تماس :
   
989305716464

   اطلاعات شخصی :
   
نام : مسعود
نام خانوادگی : جعفری 
تاریخ تولد : مرداد 1378

   زبان :
   
فارسی
انگلیسی

   مهارت ها : 
   
( Windows _ Word _ Excel )مسلط به آفیس
Vos , yatiمسلط به سوئیچ های 
Zabbix , cactiمسلط به نرم افزار های مانیتورینگ
تسلط به مفاهیم اولیه پایگاه داده های رابطه ای
Sqlآشنایی با مفاهیم پایگاه داده اوراکل و زبان 
آشنایی با مفاهیم اولیه مدیریت بانک اطلاعاتی
SQL SERVER  آشنایی با مفاهیم اولیه و نصب پایگاه داده 

   دوره های گذرانده شده : 
   
Oracle database 12c introduction to sql

   سوابق کاری : 
   
تدریس دروس ریاضی دوره دبیرستان در آموزشگاه های خصوصی
راه اندازی کتابخانه الکترونیگ به عنوان پروژه پایان دوره در مدرسه اوراکل 
مشغول به کار در حوزه پشتیبانی نرم افزار شرکت مهندسی شبکه گستران آریا سامانه

   About Me :
   
I am Masoud Jafari.
I am studying at Payame Noor University in the center of North Tehran and I am working in Aria Samaneh Network Engineering Company in the field of support.

   Phone number :
 
989305716464.

   Personal Information :
   
First Name: Masoud.
Last name: Jafari.
Date of birth: 1999 july.

   language : 
   

persian \ English

   Skills :
   

(Windows _ Word _ Excel) Fluent in Office.
Vos, yati fluent in switches.
Zabbix , cacti Fluent in monitoring software. 
Mastery of the basic concepts of relational databases. 
Sql Introduction to Oracle Database Concepts and Language Familiarity with the basic concepts of database management. 
SQL SERVER Familiarity with basic concepts and database installation.

   passed courses :
   
Oracle database 12c introduction to sql

   resume :
   

Teaching high school math lessons in private schools.
Launching an e-library as an end-of-course project at Oracle School .
Working in the field of software support of Aria Samaneh Network Engineering Company.



