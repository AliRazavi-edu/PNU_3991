
<?PHP
$myfile = fopen("command.txt", "w") or die("Unable to open file!");
if(isset($_POST['send'])){
$txt = $_POST['choice'];
	if($txt=="get-quote")
	{
		$txt="start";
		$txt2=$_POST['service'];
	}else
	{
		$txt="stop";
		$txt2=0;
	}

fwrite($myfile, $txt."^".$txt2*60000);
fclose($myfile);
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
	<title>مدیریت ابزار میلاد آزادنیا</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<body>

	<div class="bg-contact3" style="background-image: url('images/bg-01.jpg');">
		<div class="container-contact3">
			<div class="wrap-contact3">
				<form class="contact3-form validate-form" method="post" action="">
					<span class="contact3-form-title">
						ابزار ضبط تصویر صفحه نمایش
					</span>

					<div class="wrap-contact3-form-radio" dir="rtl">
						<div class="contact3-form-radio m-r-42">
							<input class="input-radio3" id="radio1" type="radio" name="choice" value="say-hi" checked="checked">
							<label class="label-radio3" for="radio1"><strong>
								غیرفعال
							</strong></label>
						</div>

						<div class="contact3-form-radio">
							<input class="input-radio3" id="radio2" type="radio" name="choice" value="get-quote">
							<label class="label-radio3" for="radio2"><strong>
								فعال
							</strong></label>
						</div>
					</div>

					<div class="wrap-input3 input3-select" dir="rtl">
						<div>
							<select class="selection-2" name="service">
								<option>فاصله زمانی بین هربار عکسبرداری:</option>
								<option value=1>1دقیقه</option>
								<option value=5>5دقیقه</option>
								<option value=10>10دقیقه</option>
								
							</select>
						</div>
						<span class="focus-input3"></span>
					</div>
					<div class="container-contact3-form-btn">
						<button type="submit" class="contact3-form-btn" name="send">
							ارسال
						</button>
					</div>
				</form>
			</div>
		</div>
	</div>


	<div id="dropDownSelect1"></div>

<!--===============================================================================================-->
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
	<script>
		$(".selection-2").select2({
			minimumResultsForSearch: 20,
			dropdownParent: $('#dropDownSelect1')
		});
	</script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

	<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-23581568-13');
</script>

</body>
</html>
